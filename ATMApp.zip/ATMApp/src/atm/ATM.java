package atm;

	import java.util.Scanner;

	public class ATM {
	    private User user;

	    public ATM(User user) {
	        this.user = user;
	    }

	    public void start() {
	    	Scanner sc = new Scanner(System.in);

	    	// Menü
	    	while(true) {
	    	    System.out.println("\n1) Bakiye Görüntüle");
	    	    System.out.println("2) Para Çekme");
	    	    System.out.println("3) Çıkış");
	    	    System.out.print("Seçiminiz: ");
	    	    
	    	    String secimStr = sc.nextLine(); // nextLine kullanıyoruz
	    	    int secim;

	    	    try {
	    	        secim = Integer.parseInt(secimStr); // string → int
	    	    } catch (NumberFormatException e) {
	    	        System.out.println("Lütfen geçerli bir sayı girin!");
	    	        continue;
	    	    }

	    	    if(secim == 1) {
	    	        System.out.println("Bakiyeniz: " + user.getBalance() + " TL");
	    	    } else if(secim == 2) {
	    	        System.out.print("Çekmek istediğiniz miktar: ");
	    	        String amountStr = sc.nextLine();
	    	        double amount;
	    	        try {
	    	            amount = Double.parseDouble(amountStr);
	    	            user.withdraw(amount);
	    	        } catch (NumberFormatException e) {
	    	            System.out.println("Geçerli bir sayı girin!");
	    	        }
	    	    } else if(secim == 3) {
	    	        System.out.println("Çıkış yapıldı.");
	    	        break;
	    	    } else {
	    	        System.out.println("Geçersiz seçim!");
	    	    }
	    	}
	    }
	}
	
	    	
