package atm;

		import java.util.Scanner;

		public class Main {
		    public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);

		        System.out.println("=== Yeni Kullanıcı Oluştur ===");
		        System.out.print("Kullanıcı adı belirleyin: ");
		        String username = sc.nextLine();
		        System.out.print("Şifre belirleyin: ");
		        String password = sc.nextLine();

		        // Başlangıç bakiyesi
		        double balance = 5000;

		        User user = new User(username, password, balance);
		        ATM atm = new ATM(user);

		        System.out.println("\nKullanıcı oluşturuldu. ATM'ye giriş yapabilirsiniz.\n");

		        atm.start();
		        sc.close();
		    }
		}


