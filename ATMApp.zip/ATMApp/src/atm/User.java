package atm;

public class User {

	    private String username;
	    private String password;
	    private double balance;

	    public User(String username, String password, double balance) {
	        this.username = username;
	        this.password = password;
	        this.balance = balance;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public boolean checkPassword(String pw) {
	        return this.password.equals(pw);
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public void withdraw(double amount) {
	        if(amount <= balance) {
	            balance -= amount;
	            System.out.println(amount + " TL çekildi. Yeni bakiye: " + balance);
	        } else {
	            System.out.println("Yetersiz bakiye!");
	        }
	    }
	}
